// src/App.tsx
"use client";

// App is just the Home page. All routing lives in main.tsx.
import Home from "./routes/Home";
export default function App() {
  return <Home />;
}
