// src/routes/Register.tsx
import React, { useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { auth, db } from "@/lib/firebase";
import {
  createUserWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

const POLICY_VERSION = "v1.0 — 2025-09-20";

export default function Register() {
  const navigate = useNavigate();

  // account
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // profile
  const [fullName, setFullName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");

  // legal
  const [agreeTos, setAgreeTos] = useState(false);
  const [agreePrivacy, setAgreePrivacy] = useState(false);

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const canSubmit = useMemo(
    () =>
      fullName.trim() &&
      email.trim() &&
      password.length >= 6 &&
      address.trim() &&
      phone.trim() &&
      agreeTos &&
      agreePrivacy,
    [fullName, email, password, address, phone, agreeTos, agreePrivacy]
  );

  function validate(): string | null {
    if (!fullName.trim()) return "Please enter your name.";
    if (!email.trim()) return "Please enter your email.";
    if (password.length < 6) return "Password must be at least 6 characters.";
    if (!address.trim()) return "Please enter your address.";
    if (!phone.trim()) return "Please enter your WhatsApp/phone number.";
    if (!agreeTos) return "You must agree to the Terms of Service.";
    if (!agreePrivacy) return "You must consent to the Customer Data notice.";
    return null;
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    const v = validate();
    if (v) return setErr(v);

    setBusy(true);
    try {
      // 1) create account
      const cred = await createUserWithEmailAndPassword(auth, email, password);

      // 2) set display name
      await updateProfile(cred.user, { displayName: fullName });

      // 3) persist profile + consent
      const userRef = doc(db, "users", cred.user.uid);
      await setDoc(
        userRef,
        {
          email,
          displayName: fullName,
          address,
          phone,
          createdAt: serverTimestamp(),
          providerIds: ["password"],
          consent: {
            tosAccepted: true,
            privacyAccepted: true,
            version: POLICY_VERSION,
            acceptedAt: serverTimestamp(),
            userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "",
          },
        },
        { merge: true }
      );

      // 4) done
      navigate("/dashboard/overview");
    } catch (e: any) {
      setErr(e?.message ?? String(e));
    } finally {
      setBusy(false);
    }
  }

  const label = "text-sm text-slate-200";
  const input =
    "w-full rounded-lg border border-white/10 bg-slate-900/60 px-3 py-2 text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500";

  return (
    <main className="min-h-screen bg-[#0b1220] flex items-center justify-center p-6">
      <form
        onSubmit={handleRegister}
        className="w-full max-w-md space-y-4 rounded-2xl border border-white/10 bg-white/5 p-6"
      >
        <h1 className="text-xl font-semibold text-white">Create an account</h1>

        <div>
          <label className={label}>Name</label>
          <input
            className={input}
            placeholder="Your full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
        </div>

        <div>
          <label className={label}>Email</label>
          <input
            type="email"
            className={input}
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </div>

        <div>
          <label className={label}>Password</label>
          <input
            type="password"
            className={input}
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>

        <div>
          <label className={label}>Address</label>
          <textarea
            rows={3}
            className={input}
            placeholder="Street, city, province, postal code"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
        </div>

        <div>
          <label className={label}>No HP (WhatsApp preferred)</label>
          <input
            className={input}
            placeholder="+62 812-xxx-xxxx"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>

        {/* Legal section */}
        <div className="mt-2 space-y-2 rounded-lg border border-white/10 bg-slate-900/40 p-3">
          <label className="flex items-start gap-3 text-sm text-slate-200">
            <input
              type="checkbox"
              className="mt-1"
              checked={agreeTos}
              onChange={(e) => setAgreeTos(e.target.checked)}
            />
            <span>
              I have read and agree to the{" "}
              <Link className="text-indigo-300 underline" to="/terms" target="_blank">
                Terms of Service
              </Link>
              .
            </span>
          </label>

          <label className="flex items-start gap-3 text-sm text-slate-200">
            <input
              type="checkbox"
              className="mt-1"
              checked={agreePrivacy}
              onChange={(e) => setAgreePrivacy(e.target.checked)}
            />
            <span>
              I consent to the{" "}
              <Link className="text-indigo-300 underline" to="/privacy" target="_blank">
                Customer Data & Privacy Notice
              </Link>
              , including use of my data for order processing, anti-fraud checks, and
              service improvements.
            </span>
          </label>

          <div className="text-[11px] text-slate-400">
            Policy version: <span className="font-mono">{POLICY_VERSION}</span>
          </div>
        </div>

        {err && (
          <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {err}
          </div>
        )}

        <button
          disabled={busy || !canSubmit}
          className="w-full rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {busy ? "Creating…" : "Sign Up"}
        </button>

        <p className="text-sm text-slate-400">
          Already have an account?{" "}
          <Link to="/login" className="text-indigo-300 hover:text-indigo-200 underline">
            Log in
          </Link>
        </p>
      </form>
    </main>
  );
}
