// src/routes/PurchaseHistory.tsx
import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/contexts/AuthProvider";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  limit,
  orderBy,
  query,
  startAfter,
  where,
  DocumentSnapshot,
  Timestamp,
} from "firebase/firestore";
import Pager from "@/components/Pager";

type Topup = {
  id?: string;
  userId: string;
  hours?: number;
  grams?: number;
  amount?: number;
  status: "approved" | "pending" | "rejected";
  createdAt?: Timestamp | { toDate: () => Date };
};

const PAGE_SIZE = 8;

export default function PurchaseHistory() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Topup[]>([]);
  const [total, setTotal] = useState<number>(0); // optional show; if unknown, set to rows.length * page
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  // Firestore cursors per page (page 1 has null cursor)
  const [cursors, setCursors] = useState<(DocumentSnapshot | null)[]>([null]);

  async function loadPage(p: number) {
    if (!user) return;
    setLoading(true);

    try {
      const base = collection(db, "topups"); // <= adjust if different
      const baseQ = query(
        base,
        where("userId", "==", user.uid),
        orderBy("createdAt", "desc"),
        limit(PAGE_SIZE + 1) // fetch one extra to detect "hasNext"
      );

      const cursor = cursors[p - 1] || null;
      const q = cursor ? query(baseQ, startAfter(cursor)) : baseQ;

      const snap = await getDocs(q);

      // slice to page size, keep the extra as "next cursor discovery"
      const docs = snap.docs.slice(0, PAGE_SIZE);
      const nextCursor = snap.docs.length > PAGE_SIZE ? snap.docs[PAGE_SIZE - 1] : null;

      // set rows
      setRows(
        docs.map((d) => ({
          id: d.id,
          ...(d.data() as any),
        }))
      );

      // store next cursor if going forward
      const newCursors = [...cursors];
      if (!newCursors[p]) newCursors[p] = docs[docs.length - 1] || newCursors[p - 1] || null;
      if (nextCursor && !newCursors[p + 1]) newCursors[p + 1] = nextCursor;
      setCursors(newCursors);

      // optional "best effort" total (for pager label); remove if you prefer not to show
      setTotal((p - 1) * PAGE_SIZE + docs.length + (nextCursor ? PAGE_SIZE : 0));
      setPage(p);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.uid]);

  function formatDate(v: any) {
    try {
      const d =
        v instanceof Timestamp ? v.toDate() : typeof v?.toDate === "function" ? v.toDate() : new Date(v);
      return d.toLocaleString();
    } catch {
      return "";
    }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold text-white">Purchase History</h1>

      <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-300">
                <th className="py-2">Created</th>
                <th className="py-2">Hours</th>
                <th className="py-2">Filament (g)</th>
                <th className="py-2">Amount</th>
                <th className="py-2">Status</th>
              </tr>
            </thead>
            <tbody className="text-slate-200">
              {rows.map((r) => (
                <tr key={r.id} className="border-t border-white/5">
                  <td className="py-2">{formatDate(r.createdAt)}</td>
                  <td className="py-2 tabular-nums">{r.hours ?? 0}</td>
                  <td className="py-2 tabular-nums">{r.grams ?? 0}</td>
                  <td className="py-2 tabular-nums">{r.amount ? `Rp ${r.amount.toLocaleString()}` : "-"}</td>
                  <td className="py-2">
                    <span
                      className={`rounded-md px-2 py-0.5 text-xs uppercase tracking-wide ${
                        r.status === "approved"
                          ? "bg-emerald-500/10 text-emerald-200 border border-emerald-400/30"
                          : r.status === "pending"
                          ? "bg-amber-500/10 text-amber-200 border border-amber-400/30"
                          : "bg-red-500/10 text-red-200 border border-red-400/30"
                      }`}
                    >
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
              {!loading && rows.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No records.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <Pager page={page} total={total} pageSize={PAGE_SIZE} onPageChange={loadPage} />
      </div>
    </div>
  );
}
