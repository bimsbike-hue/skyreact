import React, { useEffect, useMemo, useState } from "react";
import { db } from "@/lib/firebase";
import {
  collection,
  onSnapshot,
  orderBy,
  query,
  where,
  getDocs,
  QuerySnapshot,
  DocumentData,
  Timestamp,
} from "firebase/firestore";
import { PrintJob } from "@/lib/printJobs";

// ---- types ----
type TopUp = {
  id: string;
  userId: string;
  userEmail?: string | null;
  hours?: number;
  items?: Array<{ material: "PLA" | "TPU"; color: "White" | "Black" | "Gray"; grams: number }>;
  amountIDR?: number;
  note?: string;
  status: "pending" | "approved" | "rejected";
  createdAt?: Timestamp | any;
  approvedAt?: Timestamp | any;
  rejectedAt?: Timestamp | any;
  approvedBy?: string;
  rejectedBy?: string;
};

type JobCounts = {
  submitted: number;
  quoted: number;
  processing: number; // approved ∪ processing
  completed: number;
  cancelled: number;
};

const EMPTY_COUNTS: JobCounts = {
  submitted: 0,
  quoted: 0,
  processing: 0,
  completed: 0,
  cancelled: 0,
};

// ---- helpers ----
function toMillis(v: any): number {
  if (!v) return 0;
  if (v instanceof Timestamp) return v.toMillis();
  if (typeof v?.toDate === "function") return v.toDate().getTime();
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}
function sortByCreatedAtDesc(a: any, b: any) {
  return toMillis(b?.createdAt) - toMillis(a?.createdAt);
}
function mapDocs<T = any>(snap: QuerySnapshot<DocumentData>): T[] {
  const rows: any[] = [];
  snap.forEach((d) => rows.push({ id: d.id, ...(d.data() as any) }));
  return rows as T[];
}

export default function AdminDashboard() {
  // live data
  const [jobs, setJobs] = useState<PrintJob[]>([]);
  const [pendingTopUps, setPendingTopUps] = useState<TopUp[]>([]);
  const [recentTopUps, setRecentTopUps] = useState<TopUp[]>([]);
  const [loadedJobs, setLoadedJobs] = useState(false);

  // ----- Jobs listener (safe with fallback) -----
  useEffect(() => {
    const col = collection(db, "printJobs");
    const qWithOrder = query(col, orderBy("createdAt", "desc"));
    const qWithoutOrder = query(col);

    const stop = onSnapshot(
      qWithOrder,
      (snap) => {
        setJobs(mapDocs<PrintJob>(snap));
        setLoadedJobs(true);
      },
      async () => {
        // fallback: fetch without order, then sort client side, then attach live no-order
        try {
          const first = await getDocs(qWithoutOrder);
          const rows = mapDocs<PrintJob>(first).sort(sortByCreatedAtDesc);
          setJobs(rows);
          setLoadedJobs(true);
        } catch {
          setJobs([]);
          setLoadedJobs(true);
        }
        onSnapshot(qWithoutOrder, (snap2) => {
          setJobs(mapDocs<PrintJob>(snap2).sort(sortByCreatedAtDesc));
        });
      }
    );

    return stop;
  }, []);

  // ----- TopUps: pending (live) -----
  useEffect(() => {
    const col = collection(db, "topups");
    const qy = query(col, where("status", "==", "pending"));
    const stop = onSnapshot(
      qy,
      (snap) => {
        setPendingTopUps(mapDocs<TopUp>(snap).sort(sortByCreatedAtDesc));
      },
      async () => {
        const first = await getDocs(qy);
        setPendingTopUps(mapDocs<TopUp>(first).sort(sortByCreatedAtDesc));
      }
    );
    return stop;
  }, []);

  // ----- TopUps: recent approvals/rejections -----
  useEffect(() => {
    const col = collection(db, "topups");
    const qWithOrder = query(col, where("status", "in", ["approved", "rejected"]), orderBy("createdAt", "desc"));
    const qFallback = query(col, where("status", "in", ["approved", "rejected"]));

    const stop = onSnapshot(
      qWithOrder,
      (snap) => {
        const rows = mapDocs<TopUp>(snap).sort(sortByCreatedAtDesc).slice(0, 6);
        setRecentTopUps(rows);
      },
      async () => {
        const first = await getDocs(qFallback);
        const rows = mapDocs<TopUp>(first).sort(sortByCreatedAtDesc).slice(0, 6);
        setRecentTopUps(rows);
      }
    );
    return stop;
  }, []);

  // ----- Derived: counts & queue -----
  const counts = useMemo<JobCounts>(() => {
    if (!loadedJobs) return EMPTY_COUNTS;
    const out = { ...EMPTY_COUNTS };
    for (const j of jobs) {
      switch (j.status) {
        case "submitted":
          out.submitted++; break;
        case "quoted":
          out.quoted++; break;
        case "approved":
        case "processing":
          out.processing++; break;
        case "completed":
          out.completed++; break;
        case "cancelled":
          out.cancelled++; break;
      }
    }
    return out;
  }, [jobs, loadedJobs]);

  // live queue: approved/processing; sort by queuePosition then createdAt
  const queue = useMemo<PrintJob[]>(() => {
    const rows = jobs.filter(j => j.status === "approved" || j.status === "processing");
    rows.sort((a, b) => {
      const qa = a?.quote?.queuePosition ?? 999999;
      const qb = b?.quote?.queuePosition ?? 999999;
      if (qa !== qb) return qa - qb;
      return sortByCreatedAtDesc(a, b);
    });
    return rows.slice(0, 12);
  }, [jobs]);

  // recently submitted (last 8 submitted/quoted)
  const recentJobs = useMemo<PrintJob[]>(() => {
    const rows = jobs
      .filter((j) => j.status === "submitted" || j.status === "quoted")
      .slice(0, 8);
    return rows;
  }, [jobs]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-white">Admin Dashboard</h1>
        <p className="text-sm text-slate-400">Live operational overview</p>
      </div>

      {/* KPI row */}
      <div className="grid lg:grid-cols-5 md:grid-cols-3 grid-cols-2 gap-4">
        <KpiCard label="Top-Ups Pending" value={pendingTopUps.length} tone="amber" />
        <KpiCard label="Jobs Submitted" value={counts.submitted} tone="indigo" />
        <KpiCard label="Jobs Quoted" value={counts.quoted} tone="sky" />
        <KpiCard label="In Queue / Processing" value={counts.processing} tone="cyan" />
        <KpiCard label="Completed (Total)" value={counts.completed} tone="emerald" />
      </div>

      {/* Queue + Pending topups */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Queue */}
        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-white font-semibold">Current Queue</h3>
            <span className="text-xs text-slate-400">
              {queue.length} shown • {counts.processing} total in progress
            </span>
          </div>

          {queue.length === 0 ? (
            <p className="text-sm text-slate-400">No jobs in the queue yet.</p>
          ) : (
            <div className="space-y-2">
              {queue.map((j) => (
                <Row key={j.id}>
                  <div className="min-w-0">
                    <div className="text-white truncate">
                      #{j.id?.slice(0, 6)} — {j.model?.filename}
                    </div>
                    <div className="text-xs text-slate-400">
                      {j.settings?.filamentType} • {j.settings?.color}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Tag tone="sky">{j.status}</Tag>
                    {typeof j.quote?.queuePosition === "number" && (
                      <Tag tone="indigo">Queue {j.quote.queuePosition}</Tag>
                    )}
                  </div>
                </Row>
              ))}
            </div>
          )}
        </section>

        {/* Pending TopUps */}
        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-white font-semibold">Top-Ups Pending Approval</h3>
            <span className="text-xs text-slate-400">{pendingTopUps.length} awaiting</span>
          </div>

          {pendingTopUps.length === 0 ? (
            <p className="text-sm text-slate-400">No pending requests.</p>
          ) : (
            <div className="space-y-2">
              {pendingTopUps.slice(0, 10).map((t) => (
                <Row key={t.id}>
                  <div className="min-w-0">
                    <div className="text-white truncate">#{t.id?.slice(0, 6)} — {t.userEmail || t.userId}</div>
                    <div className="text-xs text-slate-400">
                      {t.hours ? `${t.hours} h` : ""}{" "}
                      {t.items && t.items.length
                        ? `• ${t.items.map(i => `${i.material} ${i.color} ${i.grams}g`).join(", ")}`
                        : ""}
                    </div>
                  </div>
                  <Tag tone="amber">pending</Tag>
                </Row>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Recent activity */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent jobs */}
        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-white font-semibold">Recently Submitted / Quoted</h3>
            <span className="text-xs text-slate-400">{recentJobs.length} shown</span>
          </div>

          {recentJobs.length === 0 ? (
            <p className="text-sm text-slate-400">No recent jobs.</p>
          ) : (
            <div className="space-y-2">
              {recentJobs.map((j) => (
                <Row key={j.id}>
                  <div className="min-w-0">
                    <div className="text-white truncate">
                      #{j.id?.slice(0, 6)} — {j.model?.filename}
                    </div>
                    <div className="text-xs text-slate-400">
                      {j.settings?.filamentType} • {j.settings?.color}
                    </div>
                  </div>
                  <Tag tone={j.status === "submitted" ? "indigo" : "amber"}>
                    {j.status}
                  </Tag>
                </Row>
              ))}
            </div>
          )}
        </section>

        {/* Recent top-up decisions */}
        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-white font-semibold">Recent Top-Up Activity</h3>
            <span className="text-xs text-slate-400">{recentTopUps.length} shown</span>
          </div>

          {recentTopUps.length === 0 ? (
            <p className="text-sm text-slate-400">No recent approvals/rejections.</p>
          ) : (
            <div className="space-y-2">
              {recentTopUps.map((t) => (
                <Row key={t.id}>
                  <div className="min-w-0">
                    <div className="text-white truncate">
                      #{t.id?.slice(0, 6)} — {t.userEmail || t.userId}
                    </div>
                    <div className="text-xs text-slate-400">
                      {t.hours ? `${t.hours} h` : ""}{" "}
                      {t.items && t.items.length
                        ? `• ${t.items.map(i => `${i.material} ${i.color} ${i.grams}g`).join(", ")}`
                        : ""}
                    </div>
                  </div>
                  <Tag tone={t.status === "approved" ? "emerald" : "rose"}>
                    {t.status}
                  </Tag>
                </Row>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

/* ---------------- UI bits ---------------- */

function KpiCard({
  label,
  value,
  tone = "indigo",
}: {
  label: string;
  value: number | string;
  tone?: "indigo" | "amber" | "emerald" | "cyan" | "sky";
}) {
  const ring =
    tone === "amber"
      ? "ring-amber-400/30 text-amber-200"
      : tone === "emerald"
      ? "ring-emerald-400/30 text-emerald-200"
      : tone === "cyan"
      ? "ring-cyan-400/30 text-cyan-200"
      : tone === "sky"
      ? "ring-sky-400/30 text-sky-200"
      : "ring-indigo-400/30 text-indigo-200";

  return (
    <div className={`rounded-2xl bg-slate-900/60 ring-1 ${ring} p-4`}>
      <div className="text-xs uppercase tracking-wider text-slate-400">{label}</div>
      <div className="mt-2 text-3xl font-semibold text-white tabular-nums">{value}</div>
    </div>
  );
}

function Tag({
  children,
  tone = "slate",
}: {
  children: React.ReactNode;
  tone?: "indigo" | "amber" | "sky" | "emerald" | "rose" | "slate" | "cyan";
}) {
  const cls =
    tone === "indigo"
      ? "bg-indigo-500/10 text-indigo-200"
      : tone === "amber"
      ? "bg-amber-500/10 text-amber-200"
      : tone === "sky"
      ? "bg-sky-500/10 text-sky-200"
      : tone === "emerald"
      ? "bg-emerald-500/10 text-emerald-200"
      : tone === "rose"
      ? "bg-rose-500/10 text-rose-200"
      : tone === "cyan"
      ? "bg-cyan-500/10 text-cyan-200"
      : "bg-slate-700/50 text-slate-200";
  return <span className={`px-2 py-0.5 rounded-md text-xs uppercase ${cls}`}>{children}</span>;
}

function Row({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-slate-800/40 px-3 py-2">
      {children}
    </div>
  );
}
