// src/routes/Dashboard.tsx
"use client";

import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../contexts/AuthProvider";
import Navbar from "../components/Navbar";

export default function Dashboard() {
  const { user } = useAuth();
  const isAdmin = user?.email === "bimsbike@gmail.com";

  if (!user) {
    return (
      <main className="p-6 max-w-6xl mx-auto text-white">
        Please sign in to view the dashboard.
      </main>
    );
  }

  const itemBase =
    "block w-full text-left px-4 py-3 rounded-lg transition bg-gray-800 text-white hover:bg-gray-700";
  const itemActive =
    "block w-full text-left px-4 py-3 rounded-lg transition bg-indigo-600 text-white";

  // User links (hide for admin)
  const userLinks = !isAdmin
    ? [
        { to: "overview", label: "Overview", end: true },
        { to: "topup", label: "Top-Up" },
        { to: "purchase-history", label: "Purchase History" },
        { to: "profile", label: "Profile" },
        { to: "new-print", label: "New Job" },
        { to: "start-print", label: "My Print Status" },
      ]
    : [];

  // Admin links
  const adminLinks = isAdmin
    ? [
        { to: "admin-dashboard", label: "Admin Dashboard" },
        { to: "admin-users",      label: "User List" },          // ✅ NEW
        { to: "start-print",      label: "Users Print Status" },
        { to: "admin",            label: "Admin Panel" },
        { to: "admin-history",    label: "User Purchase History" },
      ]
    : [];

  return (
    <div className="min-h-screen bg-[#0b1220]">
      <Navbar />

      <div className="max-w-6xl mx-auto p-6 flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <aside className="w-full lg:w-1/4 space-y-3">
          {userLinks.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end as boolean | undefined}
              className={({ isActive }) => (isActive ? itemActive : itemBase)}
            >
              {l.label}
            </NavLink>
          ))}

          {isAdmin && (
            <>
              <div className="mt-2 text-xs uppercase tracking-wide text-slate-400 px-1">
                Admin
              </div>
              {adminLinks.map((l) => (
                <NavLink
                  key={l.to}
                  to={l.to}
                  className={({ isActive }) => (isActive ? itemActive : itemBase)}
                >
                  {l.label}
                </NavLink>
              ))}
            </>
          )}
        </aside>

        {/* Main content */}
        <main className="flex-1 space-y-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
