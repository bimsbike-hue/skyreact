// src/routes/DashboardOverview.tsx
import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/contexts/AuthProvider";
import { db } from "@/lib/firebase";
import {
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  where,
  getDocs,
  QuerySnapshot,
  DocumentData,
  Timestamp,
} from "firebase/firestore";
import { PrintJob } from "@/lib/printJobs";

type WalletSummary = {
  hours: number;
  filament?: Record<string, Record<string, number>>;
};

type StatusCounts = {
  submitted: number;
  quoted: number;
  processing: number; // approved ∪ processing
  completed: number;
};

const EMPTY_COUNTS: StatusCounts = {
  submitted: 0,
  quoted: 0,
  processing: 0,
  completed: 0,
};

export default function DashboardOverview() {
  const { user } = useAuth();

  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [jobs, setJobs] = useState<PrintJob[]>([]);
  const [loadedJobs, setLoadedJobs] = useState(false);

  // ---- Wallet (live) ----
  useEffect(() => {
    if (!user) return;
    const ref = doc(db, "users", user.uid, "wallet", "summary");
    const stop = onSnapshot(ref, (snap) => {
      if (snap.exists()) setWallet(snap.data() as WalletSummary);
    });
    return stop;
  }, [user?.uid]);

  // ---- Jobs (live) ----
  useEffect(() => {
    if (!user) return;

    const baseCol = collection(db, "printJobs");
    const qWithOrder = query(
      baseCol,
      where("userId", "==", user.uid),
      orderBy("createdAt", "desc")
    );
    const qWithoutOrder = query(baseCol, where("userId", "==", user.uid));

    const stop = onSnapshot(
      qWithOrder,
      (snap) => {
        setJobs(mapJobs(snap));
        setLoadedJobs(true);
      },
      async () => {
        try {
          const first = await getDocs(qWithoutOrder);
          const initial = mapJobs(first).sort(sortByCreatedAtDesc);
          setJobs(initial);
          setLoadedJobs(true);
        } catch {
          setJobs([]);
          setLoadedJobs(true);
        }
        onSnapshot(qWithoutOrder, (snap2) => {
          const rows = mapJobs(snap2).sort(sortByCreatedAtDesc);
          setJobs(rows);
        });
      }
    );

    return stop;
  }, [user?.uid]);

  // ---- Derived counters and recent ----
  const counts = useMemo<StatusCounts>(() => {
    if (!loadedJobs) return EMPTY_COUNTS;
    const out = { ...EMPTY_COUNTS };
    for (const j of jobs) {
      switch (j.status) {
        case "submitted":
          out.submitted++;
          break;
        case "quoted":
          out.quoted++;
          break;
        case "approved":
        case "processing":
          out.processing++;
          break;
        case "completed":
          out.completed++;
          break;
      }
    }
    return out;
  }, [jobs, loadedJobs]);

  const recentJobs = useMemo(() => jobs.slice(0, 4), [jobs]);

  /** Format decimal hours -> "X Hours : Y Minutes" */
  function formatHoursVerbose(hours: number | null | undefined): string {
    const h = Number(hours ?? 0);
    if (!Number.isFinite(h) || h <= 0) return "0 Hours : 0 Minutes";
    const whole = Math.floor(h);
    let minutes = Math.round((h - whole) * 60);

    if (minutes === 60) {
      minutes = 0;
      return `${whole + 1} Hours : 0 Minutes`;
    }
    return `${whole} Hours : ${minutes} Minutes`;
  }

  function renderFilament() {
    if (!wallet?.filament) return null;
    return (
      <div className="grid md:grid-cols-2 gap-6">
        {Object.entries(wallet.filament).map(([type, colors]) => {
          const total = Object.values(colors).reduce((a, b) => a + b, 0);
          return (
            <div
              key={type}
              className="rounded-lg border border-white/10 bg-slate-900/40 p-4"
            >
              <div className="mb-2 font-semibold text-white">{type}</div>
              <div className="space-y-1 text-sm text-slate-300">
                {Object.entries(colors).map(([color, grams]) => (
                  <div key={color} className="flex justify-between">
                    <span>{color}</span>
                    <span>{grams} g</span>
                  </div>
                ))}
                <div className="mt-1 border-t border-white/10 pt-1 flex justify-between font-semibold text-slate-200">
                  <span>Total</span>
                  <span>{total} g</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Row */}
      <div className="grid md:grid-cols-2 gap-4">
        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="text-sm text-slate-400">Hours Balance</div>
          <div className="mt-2 text-2xl font-bold text-white">
            {formatHoursVerbose(wallet?.hours)}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Usable for print jobs (Hours : Minutes)
          </p>
        </section>

        <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <h3 className="text-white font-semibold mb-3">My Print Status</h3>
          <div className="grid grid-cols-2 gap-3">
            <StatusPill label="submitted" count={counts.submitted} tint="indigo" />
            <StatusPill label="quoted" count={counts.quoted} tint="amber" />
            <StatusPill label="processing" count={counts.processing} tint="sky" />
            <StatusPill label="completed" count={counts.completed} tint="emerald" />
          </div>
        </section>
      </div>

      {/* Filament details */}
      <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
        <h3 className="text-white font-semibold mb-3">Filament details</h3>
        <p className="text-xs text-slate-400 mb-4">
          Breakdown by material and color (live wallet balances)
        </p>
        {renderFilament()}
      </section>

      {/* Recent Orders */}
      <section className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
        <h3 className="text-white font-semibold mb-3">Recent Orders</h3>
        {!loadedJobs ? (
          <p className="text-sm text-slate-400">Loading…</p>
        ) : recentJobs.length === 0 ? (
          <p className="text-sm text-slate-400">No orders yet.</p>
        ) : (
          <div className="space-y-2">
            {recentJobs.map((job) => (
              <div
                key={job.id}
                className="flex items-center justify-between rounded-lg bg-slate-800/40 px-3 py-2 text-sm"
              >
                <div className="flex flex-col min-w-0">
                  <span className="text-white truncate">
                    #{job.id?.slice(0, 5)} — {job.model?.filename}
                  </span>
                  <span className="text-xs text-slate-400">
                    {job.settings?.filamentType} · {job.settings?.color}
                  </span>
                </div>
                <span className="rounded-md bg-slate-700/50 px-2 py-0.5 text-[11px] uppercase tracking-wide text-slate-300">
                  {job.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function mapJobs(snap: QuerySnapshot<DocumentData>): PrintJob[] {
  const rows: PrintJob[] = [];
  snap.forEach((d) => rows.push({ ...(d.data() as any), id: d.id }));
  return rows;
}

function sortByCreatedAtDesc(a: any, b: any) {
  const ta = toMillis(a?.createdAt);
  const tb = toMillis(b?.createdAt);
  return tb - ta;
}

function toMillis(v: any): number {
  if (!v) return 0;
  if (v instanceof Timestamp) return v.toMillis();
  if (typeof v?.toDate === "function") return v.toDate().getTime();
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function StatusPill({
  label,
  count,
  tint = "indigo",
}: {
  label: string;
  count: number | string;
  tint?: "indigo" | "amber" | "sky" | "emerald";
}) {
  const ring =
    tint === "indigo"
      ? "ring-indigo-400/30 text-indigo-200"
      : tint === "amber"
      ? "ring-amber-400/30 text-amber-200"
      : tint === "sky"
      ? "ring-sky-400/30 text-sky-200"
      : "ring-emerald-400/30 text-emerald-200";

  const dot =
    tint === "indigo"
      ? "bg-indigo-400/70"
      : tint === "amber"
      ? "bg-amber-400/70"
      : tint === "sky"
      ? "bg-sky-400/70"
      : "bg-emerald-400/70";

  return (
    <div className={`flex items-center gap-3 rounded-xl bg-slate-900/60 ring-1 ${ring} px-4 py-3`}>
      <span className={`h-2.5 w-2.5 rounded-full ${dot}`} />
      <span className="text-xs uppercase tracking-wider">{label}</span>
      <span className="ml-auto rounded-md bg-white/5 px-2 py-0.5 text-sm font-semibold text-white tabular-nums">
        {count}
      </span>
    </div>
  );
}
