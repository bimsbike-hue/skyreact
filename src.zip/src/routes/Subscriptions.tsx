export default function Subscriptions() {
  return (
    <div className="p-6 text-white">
      <h2 className="text-2xl font-bold mb-4">Subscriptions</h2>
      <p>Manage weekly and monthly printer packages.</p>
    </div>
  );
}
