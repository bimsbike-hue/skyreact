// src/routes/ResetPassword.tsx
import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import {
  auth
} from "../lib/firebase";
import {
  sendPasswordResetEmail,
  verifyPasswordResetCode,
  confirmPasswordReset,
} from "firebase/auth";

/** Tiny helper */
function useQuery() {
  const { search } = useLocation();
  return useMemo(() => new URLSearchParams(search), [search]);
}

export default function ResetPassword() {
  const q = useQuery();
  const navigate = useNavigate();

  // URL params (present when user clicks the email link)
  const mode = q.get("mode"); // e.g. 'resetPassword'
  const oobCode = q.get("oobCode");
  const continueUrl = q.get("continueUrl") || "/login";

  const isConfirmFlow = mode === "resetPassword" && !!oobCode;

  // --- common UI state
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  // --- phase 1: request email
  const [email, setEmail] = useState("");

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setOk(null);
    setBusy(true);
    try {
      await sendPasswordResetEmail(auth, email.trim(), {
        url: `${window.location.origin}/reset-password?continueUrl=${encodeURIComponent(
          continueUrl
        )}`,
        handleCodeInApp: true,
      });
      setOk("Reset email sent! Please check your inbox.");
    } catch (e: any) {
      setErr(e?.message ?? "Failed to send reset email.");
    } finally {
      setBusy(false);
    }
  }

  // --- phase 2: confirm new password
  const [verifiedEmail, setVerifiedEmail] = useState<string | null>(null);
  const [newPass, setNewPass] = useState("");
  const [newPass2, setNewPass2] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function verify() {
      if (!isConfirmFlow) return;
      setErr(null);
      setOk(null);
      setBusy(true);
      try {
        // This throws if code is invalid/expired.
        const em = await verifyPasswordResetCode(auth, oobCode!);
        if (!cancelled) setVerifiedEmail(em);
      } catch (e: any) {
        if (!cancelled)
          setErr("Invalid or missing code.");
      } finally {
        if (!cancelled) setBusy(false);
      }
    }
    verify();
    return () => {
      cancelled = true;
    };
  }, [isConfirmFlow, oobCode]);

  async function handleConfirm(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setOk(null);

    if (!newPass || newPass.length < 6) {
      setErr("Password must be at least 6 characters.");
      return;
    }
    if (newPass !== newPass2) {
      setErr("Passwords do not match.");
      return;
    }

    setBusy(true);
    try {
      await confirmPasswordReset(auth, oobCode!, newPass);
      setOk("Password updated. You can now sign in.");
      // Optional: fast-redirect after a short delay
      setTimeout(() => navigate(continueUrl || "/login", { replace: true }), 1200);
    } catch (e: any) {
      setErr(e?.message ?? "Failed to update password.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Navbar />

      <main className="max-w-md mx-auto p-6 text-white">
        <h1 className="text-2xl font-bold mb-4">Reset Password</h1>

        {err && (
          <div className="mb-3 rounded border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
            {err}
          </div>
        )}
        {ok && (
          <div className="mb-3 rounded border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200">
            {ok}
          </div>
        )}

        {/* ---------- PHASE 2: user arrived via email link (oobCode present) ---------- */}
        {isConfirmFlow ? (
          verifiedEmail ? (
            <form onSubmit={handleConfirm} className="space-y-4">
              <p className="text-slate-300">
                Resetting password for <span className="font-medium">{verifiedEmail}</span>
              </p>

              <input
                type="password"
                placeholder="New password"
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                className="w-full px-3 py-2 rounded bg-gray-800 text-white"
              />
              <input
                type="password"
                placeholder="Confirm new password"
                value={newPass2}
                onChange={(e) => setNewPass2(e.target.value)}
                className="w-full px-3 py-2 rounded bg-gray-800 text-white"
              />

              <button
                type="submit"
                disabled={busy}
                className="w-full py-2 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
              >
                {busy ? "Updating…" : "Update Password"}
              </button>

              <div className="mt-4 text-sm text-slate-400 text-right">
                <Link to="/login" className="text-indigo-400 hover:underline">
                  Back to Login
                </Link>
              </div>
            </form>
          ) : (
            // verifying… or invalid code handled above in 'err'
            <p className="text-slate-400">Checking your reset link…</p>
          )
        ) : (
          /* ---------- PHASE 1: send reset email ---------- */
          <form onSubmit={handleSend} className="space-y-4">
            <p className="text-slate-300">
              Enter your email. We’ll send you a password reset link.
            </p>
            <input
              type="email"
              required
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 rounded bg-gray-800 text-white"
            />
            <button
              type="submit"
              disabled={busy}
              className="w-full py-2 rounded bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
            >
              {busy ? "Sending…" : "Send Reset Link"}
            </button>

            <div className="mt-4 flex items-center justify-between text-sm text-slate-400">
              <Link to="/login" className="text-indigo-400 hover:underline">
                Back to Login
              </Link>
              <Link to="/signup" className="text-indigo-400 hover:underline">
                Create account
              </Link>
            </div>
          </form>
        )}
      </main>
    </>
  );
}
