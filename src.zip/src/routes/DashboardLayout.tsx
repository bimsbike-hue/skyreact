// src/routes/DashboardLayout.tsx
import { NavLink, Outlet } from "react-router-dom";

const tabBase =
  "w-full text-left px-4 py-3 rounded-md bg-slate-800/70 hover:bg-slate-700/60 text-slate-200";
const tabActive = "bg-indigo-600 text-white";

function SideItem({
  to,
  children,
}: {
  to: string; // RELATIVE path under /dashboard/*
  children: React.ReactNode;
}) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) => `${tabBase} ${isActive ? tabActive : ""}`}
    >
      {children}
    </NavLink>
  );
}

export default function DashboardLayout() {
  return (
    <div className="min-h-[calc(100vh-64px)] text-white">
      <div className="mx-auto max-w-6xl grid grid-cols-1 md:grid-cols-[280px,1fr] gap-6 p-6">
        {/* Sidebar */}
        <aside className="space-y-3">
          <SideItem to="overview">Overview</SideItem>
          <SideItem to="topup">Top-Up</SideItem>
          <SideItem to="purchase-history">Purchase History</SideItem>
          <SideItem to="profile">Profile</SideItem>

          {/* NEW user menu */}
          <div className="h-px bg-white/10 my-2" />
          <SideItem to="new-print">New Job</SideItem>
          <SideItem to="my-jobs">My Jobs</SideItem>

          {/* Admin operator screen */}
          <div className="h-px bg-white/10 my-2" />
          <SideItem to="start-print">Start Print</SideItem>
        </aside>

        {/* Nested content under /dashboard/* */}
        <section className="min-h-[60vh]">
          <Outlet />
        </section>
      </div>
    </div>
  );
}
// src/routes/DashboardLayout.tsx
import { NavLink, Outlet } from "react-router-dom";

const tabBase =
  "w-full text-left px-4 py-3 rounded-md bg-slate-800/70 hover:bg-slate-700/60 text-slate-200";
const tabActive = "bg-indigo-600 text-white";

function SideItem({
  to,
  children,
}: {
  to: string; // RELATIVE path under /dashboard/*
  children: React.ReactNode;
}) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) => `${tabBase} ${isActive ? tabActive : ""}`}
    >
      {children}
    </NavLink>
  );
}

export default function DashboardLayout() {
  return (
    <div className="min-h-[calc(100vh-64px)] text-white">
      <div className="mx-auto max-w-6xl grid grid-cols-1 md:grid-cols-[280px,1fr] gap-6 p-6">
        {/* Sidebar */}
        <aside className="space-y-3">
          <SideItem to="overview">Overview</SideItem>
          <SideItem to="topup">Top-Up</SideItem>
          <SideItem to="purchase-history">Purchase History</SideItem>
          <SideItem to="profile">Profile</SideItem>

          {/* NEW user menu */}
          <div className="h-px bg-white/10 my-2" />
          <SideItem to="new-print">New Job</SideItem>
          <SideItem to="my-jobs">My Jobs</SideItem>

          {/* Admin operator screen */}
          <div className="h-px bg-white/10 my-2" />
          <SideItem to="start-print">Start Print</SideItem>
        </aside>

        {/* Nested content under /dashboard/* */}
        <section className="min-h-[60vh]">
          <Outlet />
        </section>
      </div>
    </div>
  );
}
