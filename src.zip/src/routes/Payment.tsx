// src/routes/Payment.tsx
import React from "react";
import { useNavigate } from "react-router-dom";

export default function Payment() {
  const navigate = useNavigate();

  function goToHistory() {
    // ✅ Navigate to dashboard's purchase-history tab
    navigate("/dashboard/purchase-history");
  }

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-6 text-white">
      <h1 className="text-2xl font-bold">Payment</h1>

      <div className="rounded-xl border border-white/10 bg-slate-900/60 p-4 space-y-4">
        <h2 className="text-lg font-semibold">Bank Transfer</h2>
        <p className="text-sm text-slate-300">
          Please continue your payment using the bank information below. After
          your payment is verified and approved by the admin, your top-up will
          be applied automatically.
        </p>

        <div className="rounded-md border border-white/10 bg-black/30 p-3 space-y-1">
          <p>
            BCA : <span className="font-bold">5271041536</span>
          </p>
          <p>
            A/N : <span className="font-bold">Bima Pratama Putra</span>
          </p>
        </div>

        <button
          onClick={goToHistory}
          className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm"
        >
          View my purchase history
        </button>
      </div>
    </div>
  );
}
